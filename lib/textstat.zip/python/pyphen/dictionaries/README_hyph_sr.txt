Serbian hyphenation patterns are derived from the official TeX patterns for 
Serbocroatian language (Cyrillic and Latin) created by Dejan Muhamedagić, 
version 2.02 from 22 June 2008 adopted for usage with Hyphen hyphenation
library and released under GNU LGPL version 2.1 or later.
