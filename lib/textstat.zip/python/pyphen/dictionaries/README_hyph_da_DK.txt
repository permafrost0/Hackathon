Language: Danish (da DK).
Origin:   Based on the TeX hyphenation tables
          Created by Frank Jensen (fj@iesd.auc.dk), ca. 1988.
          Modified by Preben Randhol (September 12, 1994) to increase portability between different systems
License:  GNU LGPL license.
Author:   conversion author is Marco Huggenberger<marco@by-night.ch>

This dictionary is based on syllable matching patterns and therefore should be usable under other variations of Danish

HYPH da DK hyph_da_DK
